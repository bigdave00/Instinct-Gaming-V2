$(document).ready(function () {
  window.addEventListener("message", function (event) {
    var data = event.data;
    //console.log('Hud:', data.togglefuel)
    //console.log('js fuel: ', data.fuel)
    let isFuelHudEnabled = false;
    let lastFuelDataTimestamp = null;
    const fuelHud = document.getElementById("fuel-hud");

    function checkFuelData() {
      const currentTimestamp = Date.now();
      const isEnabled = data.togglefuel === 1;

      if (isEnabled !== isFuelHudEnabled) {
        isFuelHudEnabled = isEnabled;
        fuelHudChange(isFuelHudEnabled);
      }

      if (isEnabled) {
        lastFuelDataTimestamp = currentTimestamp;
      } else if (
        lastFuelDataTimestamp !== null &&
        currentTimestamp - lastFuelDataTimestamp >= 10000
      ) {
        isFuelHudEnabled = false;
        fuelHudChange(isFuelHudEnabled);
      }
    }

    function fuelHudChange(isEnabled) {
      fuelHud.style.display = isEnabled ? "block" : "none";
    }

    if (data.togglefuel !== undefined) {
      isFuelHudEnabled = data.togglefuel === 1;
      fuelHudChange(isFuelHudEnabled);
    }
    function checkStressData() {
      const currentTimestamp = Date.now();
      const isEnabled = data.stressshow === true;
    
      if (isEnabled !== isStressHudEnabled) {
        isStressHudEnabled = isEnabled;
        stressHudVisibility(isStressHudEnabled);
      }
    }
    
    function stressHudVisibility(isEnabled) {
      const stressHudElement = document.getElementById("stress");
      stressHudElement.style.display = isEnabled ? "block" : "none";
    }
    
    if (data.stressshow !== undefined) {
      isStressHudEnabled = data.stressshow === true;
      stressHudVisibility(isStressHudEnabled);
    }
    
    

    

    $("#fuel").css("width", data.fuel + "%");
    if (data.toggle == true) {
      $(".hud-container").css("opacity", "1");
      $("#health").css("width", data.health + "%");
      $("#armour").css("width", data.armour + "%");
      $("#hunger").css("width", data.hunger + "%");
      $("#voice").css("width", data.voice + "%");
      $("#thirst").css("width", data.thirst + "%");
      $("#stamina").css("width", data.stamina + "%");
      $("#stress").css("width", data.stress + "%");
      $("#voice").css("background-color", "#bbbbbb");
      $("#voice-hud .fa-walkie-talkie")
        .removeClass("fa-walkie-talkie")
        .addClass("fa-microphone");
    } else if (data.toggle == false) {
      $(".hud-container").css("opacity", "0");
    }

    if (data.armouroff) {
      $("#armour-hud").css("display", "none");
    } else {
      $("#armour-hud").css("display", "block");
    }

    if (data.staminaoff) {
      $("#stamina-hud").css("display", "block");
    } else {
      $("#stamina-hud").css("display", "none");
    }

    if (data.stressshow) {
      $("#stress-hud").css("display", "block");
    } else {
      $("#stress-hud").css("display", "none");
    }

    if (data.talking == "1") {
      if (data.radio == "1") {
        $("#voice").css("background-color", "#8000ff");
      } else {
        $("#voice").css("background-color", "#ffae00");
      }
    } else if (data.talking == "false") {
      $("#voice").css("background-color", "#bbbbbb");
    }

    if (data.radio == "1") {
      $("#voice-hud .fa-microphone")
        .removeClass("fa-microphone")
        .addClass("fa-walkie-talkie");
    } else if (data.talking == "false") {
      $("#voice-hud .fa-walkie-talkie")
        .removeClass("fa-walkie-talkie")
        .addClass("fa-microphone");
    }

    function fadeHUD(type, hud) {
      if (type == "Out") {
        $(`#${hud}-hud`).css("opacity", "0");
        setTimeout(function () {
          $(`#${hud}-hud`).css("height", "0");
          $(`#${hud}-hud`).css("margin", "0");
        }, 500);
      } else if (type == "In") {
        $(`#${hud}-hud`).css("height", "2vh");
        $(`#${hud}-hud`).css("margin", ".3vh 0 .3vh 0");
        setTimeout(function () {
          $(`#${hud}-hud`).css("opacity", "1");
        }, 500);
      }
    }
  });
});
