INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('watertank', 'Water Tank', 100)
;