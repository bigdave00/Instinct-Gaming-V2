['watertank'] = {
    label = 'Water Tank',
    weight = 1,
    stack = true,
    close = true,
    description = nil
},