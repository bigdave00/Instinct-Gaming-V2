INSERT INTO `items` (`name`, `label`, `limit`) VALUES
	('watertank', 'Water Tank', 100)
;