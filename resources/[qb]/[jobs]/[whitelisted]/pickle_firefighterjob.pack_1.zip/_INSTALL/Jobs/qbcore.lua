['firefighter'] = {
    label = 'Firefighter',
    defaultDuty = true,
    offDutyPay = false,
    grades = {
        ['0'] = {
            name = 'Recruit',
            payment = 0
        },
        ['1'] = {
            name = 'Operator',
            payment = 0
        },
        ['2'] = {
            name = 'Company Officer',
            payment = 0
        },
        ['3'] = {
            name = 'Chief',
            isboss = true, 
            bankAuth = true,
            payment = 0
        },
    },
},