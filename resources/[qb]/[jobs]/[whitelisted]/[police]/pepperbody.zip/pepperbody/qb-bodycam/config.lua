Config = Config or {}

Config.Gender1 = ""
Config.Gender2 = ""

Config.Debug = false